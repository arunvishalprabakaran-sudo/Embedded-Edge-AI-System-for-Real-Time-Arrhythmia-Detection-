# ECG Arrhythmia Edge AI — Raspberry Pi 4 + ADS1292R

Press **START** → exactly 5 s of ECG is acquired → filtered → 3 ONNX models run once → filtered waveform + result
are shown → system returns to idle. Nothing runs in the background; the next cycle starts only on the next START.

```
ecg_edge/        runtime package (config, acquisition, preprocessing, quality, features, models, decision, pipeline, hmi, voice)
run_hmi.py       entry point
models/          3 trained ONNX models (+ SHA256SUMS)
tools/           check_acquisition.py (hardware check), replay_window.py (offline replay), inspect_ads1292r.py (SPI probe)
tests/           46 tests (decision table, label maps, training-feature parity, acquisition timing, HMI)
docs/            CHANGES.md, CLASSIFICATION_LOGIC.md (open question!), legacy/
research/afib/   removed-from-runtime AFib branch
training/        training code (untouched)
```

## Run (on the Pi)
```bash
sudo raspi-config nonint do_spi 0                       # enable SPI
sudo apt install python3-tk espeak-ng pulseaudio-utils
pip3 install -r requirements.txt
python3 tools/inspect_ads1292r.py                       # 1. wiring / SPI / register probe
python3 tools/check_acquisition.py -n 5 --save captures # 2. real 5 s captures: timing, noise, saves .npy
python3 run_hmi.py                                      # 3. HMI  (add --no-voice to silence)
```
No hardware / dev machine: `python3 run_hmi.py --mock VF` (kinds: NSR TACHY BRADY VF VT FLAT LEADOFF) - clearly bannered as simulated.
Replay a saved capture: `python3 tools/replay_window.py captures/<file>.npy`.
Tests: `pip install -r requirements-dev.txt && xvfb-run -a pytest` (HMI tests need a display; `xvfb-run` on headless boxes).

## Verified vs not verified
**Verified here (x86 sandbox, no Pi, no ADS1292R):** 46 automated tests pass: decision table incl. conflicts; ONNX I/O and label maps;
feature code equals the real training functions; resample/filter correctness; exactly 2500 samples/5 s per Start, one inference per model,
ADC stopped after every cycle and on errors, nothing runs while idle; HMI start/idle/restart/cancel under Xvfb; ADS1292R driver register
sequence, 24-bit decoding, DRDY timeout against a *fake* SPI/GPIO.
**NOT verified:** anything on real hardware (true DRDY timing at 500 SPS under Python, SPI reads, electrode signal quality, Pi inference latency,
audio sink). Run `tools/check_acquisition.py` first; if it reports lost samples, tell me the numbers.
**Model accuracy is not validated here.** Only synthetic ECG was available; probabilities there were frequently near 0.5.
Please validate with real/simulator recordings (save with `check_acquisition.py --save`).

Research prototype — not a medical device.
